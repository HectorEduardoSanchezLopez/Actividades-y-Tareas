class Article < ActiveRecord::Base
  belongs_to :user
  validates :title, :presence => true, length: {minimum: 8}, :uniqueness => true
  validates :body, :presence => true, length: {minimum: 8}
end
