class AddUserIdToArticles < ActiveRecord::Migration
  def change
  add_reference :articles, :user, foreign_key: true  #LINEA QUE CORRIGE EL ERRROR DE LA MIGRACION
    
#add_column :articles, :user, :string
#add_reference :articles, :, index: true, foreign_key: true
  end
end
